Abdelrahman Yaseen
2175578
17/11/2018

The aim of this project is to implement a raytracer. 
you can use the file "SceneGenerator.py" to generate your scenes
you can use the file "CameraGenerator.py" to generate your cameras
you can use the file "RayTracer.py" to render an image, given the correct parameters

you can execute "python Raytracer.py" to get a hint on what parameters does the program expect

