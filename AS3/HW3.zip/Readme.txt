Abdelrahman Yaseen 2175578

Compiled and run on Ubuntu 16.4
Compile Command :  gcc -o app render.c -lglfw -lGL -lGLU -lm -w
Run Command : ./app

I've tried to indicate the position of the light sourse using a polygon.
You can move the light position using the keys X Y Z on the keyboard.
Press M to toggle the mode: Decrement/Increment

The demo file shows the output while moving the light.
